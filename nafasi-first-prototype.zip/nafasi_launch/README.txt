NAFASI — FIRST WORKING PROTOTYPE

Files:
- nafasi.html: responsive browser app prototype
- marketing-kit.md: video storyboard, short script, launch posts, landing page copy, validation plan

HOW TO RUN
1. Download and unzip the package if you downloaded the ZIP.
2. Open nafasi.html in a modern web browser (Chrome, Edge, Firefox, Safari).
3. Navigate using the left menu on desktop or bottom menu on a phone-sized browser.
4. Change the sample budget and click Save my plan. Create a savings goal and try the other sections.

IMPORTANT LIMITS
- This is a front-end prototype, not a deployed public app.
- Data is saved in local browser storage on that device only. It does not sync between devices.
- No login, cloud backend, payment processing, live merchant offers, bank integration, or M-Pesa integration is included.
- Opportunity cards are practical ideas, not live discounts.
- Do not use sensitive information or shared devices for real financial data.
