# Nafasi — launch and marketing kit

**Working name:** Nafasi (check business-name, trademark, domain, and social-handle availability before commercial launch)

**Tagline:** Plan. Save. Spend smarter.

**Positioning:** A Kenya-first money companion that helps people plan available money around essentials, track goals, and find practical ways to reduce everyday spending.

**Promise:** Know what you have. Know what matters next. Find ways to make your money go further.

## 30-second launch video (vertical 9:16)

**Style:** premium, warm, optimistic, authentic Kenyan everyday life; emerald green, ivory, natural daylight; upbeat, gentle percussion; captions on screen; show the prototype only as a concept/demo.

- **0–4 sec — The problem**: Quick shots of someone checking fare, groceries, and upcoming bills. On-screen: “Ever wondered where your money went?”
- **4–8 sec — The reset**: Person pauses, opens Nafasi on a phone. On-screen: “Meet Nafasi.”
- **8–14 sec — Plan**: Show app dashboard and money planner. On-screen: “Plan around what matters.” Voiceover: “Start with what you have. Plan for essentials before you spend.”
- **14–20 sec — Goals**: Show emergency fund progress. On-screen: “Small steps. Real goals.” Voiceover: “Build a savings goal at your own pace.”
- **20–25 sec — Opportunities**: Show saving tips / comparing prices. On-screen: “Find smarter ways to spend.” Voiceover: “Explore practical ideas to make everyday money go further.”
- **25–30 sec — Call to action**: Logo, emerald background. On-screen: “Nafasi — Plan. Save. Spend smarter. Join the early-access list.” Voiceover: “Nafasi. More room for what matters.”

**Caption/disclaimer:** “Nafasi is an early prototype. Features and offers shown are illustrative and not connected to banks or M-Pesa. It does not guarantee savings or financial outcomes.”

## 15-second cutdown

“Money has a lot to do. Give it a plan. Nafasi helps you map essential expenses, track savings goals, and explore smarter spending ideas. Nafasi — Plan. Save. Spend smarter. Join our early-access test.”

## Social launch posts

### Instagram / TikTok
Your money works hard. Let’s give it a plan. 🌱

Meet **Nafasi** — a new Kenya-first money companion concept designed to help you plan essentials, track goals, and explore ways to spend smarter.

We’re building the first version and looking for people to test it. What’s the hardest part of making money last until your next income?

#Nafasi #MoneyHabits #Kenya #PersonalFinance #SaveSmarter

### X
We’re building Nafasi: a simple money companion to plan essentials, track savings goals, and explore smarter everyday spending. We’re looking for early testers in Kenya. What’s the one money task you wish were easier?

### WhatsApp invite
Hi! I’m testing an early version of Nafasi, a simple tool to help people plan everyday expenses and savings goals. It’s a prototype, not a bank app, and it doesn’t connect to M-Pesa. Would you be willing to try it for a few minutes and tell me what is useful or confusing? Honest feedback is welcome.

## Landing page copy

**Headline:** More room for what matters.

**Subheadline:** Plan everyday expenses, keep your goals in sight, and discover practical ways to spend smarter — all in one simple money companion.

**Primary CTA:** Join the early-access test

**Three benefits:**
- **Plan clearly:** See how planned essentials compare with the money you have available.
- **Make progress:** Set a goal and follow your progress at your own pace.
- **Spend thoughtfully:** Use practical saving ideas and, as the service develops, verified local offers.

**Trust note:** Nafasi does not hold your money, request your M-Pesa PIN, or guarantee financial results. Early versions use manually entered information.

## Early validation plan

1. Invite 10–15 people who manage their own everyday expenses.
2. Ask them to complete one realistic planning task in the prototype.
3. Observe where they hesitate; don't coach them through every step.
4. Ask: “What would you use again?”, “What is missing?”, “What would you trust this app to do?”, and “Would you pay for a specific advanced feature? Why or why not?”
5. Measure task completion, return use, useful actions taken, and actual willingness to pay. Do not treat compliments or likes as proof of demand.
6. Do not advertise discounts until a merchant, price, dates, and terms have been verified.

## Monetization experiments (not promises)

- Keep essential budgeting free while testing product value.
- Test a small optional premium tier for advanced reports, multiple plans, and extra reminders only after repeat use is demonstrated.
- Explore clearly disclosed affiliate referrals or paid merchant placements only when relevant and verified.
- Never sell personal financial data or make recommendations based solely on commission.

## Important before public launch

- Check Nafasi name, domain, trademark, and social-handle availability.
- Add a privacy notice and terms that match the actual product.
- Review Kenya data-protection requirements before collecting user financial data.
- Use secure authentication and server-side storage before multi-user accounts.
- Do not claim live prices, verified offers, M-Pesa integration, bank integrations, or automatic financial advice unless implemented and tested.
